/*
	Name:			parcer.c
	Purpose:
	Author:			Alexander Suvorov (www.open-plc.com)
	Created:		2017/12
	Modified by:
	RCS-ID:
	Copyright:		(c) Alexander Suvorov
	Licence:		The MIT License (MIT)
*/


#define S_I_NN 7	// max S_I_NN parameters

int parce_str( char *str, int n_prm )	// return to str parameter # n_prm
{
	int		i, j, k, n, n1, n2, count_prm;
	int		space_index[S_I_NN];
	char	s[128];

	n = strlen( ( char* ) usart_rx_data );
	//for( i = 0; i < RX_LEN; i++ )
	//{
		str[0] = 0;
		count_prm = 0;
	//}

	if( ( n_prm < 1 ) || ( n_prm > S_I_NN ) )
	{
		return 0;
	}

	if( n )		// Length > 0
	{
		// -----------------------------------------------------------
		// Trim left spaces
		// -----------------------------------------------------------
		j = 0;
		while( usart_rx_data[0] == ' ' )
		{
			n = strlen( ( char* ) usart_rx_data );
			for( j = 0; j < n; j++ )
			{
				usart_rx_data[j] = usart_rx_data[j + 1];
			}
		}
		// -----------------------------------------------------------


		// -----------------------------------------------------------
		// Trim right spaces
		// -----------------------------------------------------------
		n = strlen( ( char* ) usart_rx_data ) - 1;
		if( n > 0 )
		{
			while( usart_rx_data[n] == ' ' )
			{
				if( n >= 0 )
				{
					usart_rx_data[n] = 0;
					if( n )
					{
						n--;
					}
				}
			}
		}
		// -----------------------------------------------------------


		// -----------------------------------------------------------
		// Prepare cmd string
		// -----------------------------------------------------------
		n = strlen( ( char* ) usart_rx_data );
		for( i = 0; i < n; i++ )
		{
			if( ( usart_rx_data[i] < 32 ) || ( usart_rx_data[i] > 126 ) )
			{
				if( usart_rx_data[i] )
				{
					usart_rx_data[i] = '$';
				}
			}
			if( usart_rx_data[i] > 96 )
			{
				usart_rx_data[i] -= 32;		// to upper
			}

			while( ( usart_rx_data[i] == ' ' ) && ( usart_rx_data[i + 1] == ' ' ) )
			{
				for( j = i; j < n; j++ )
				{
					usart_rx_data[j] = usart_rx_data[j + 1];
				}
			}
		}	// for( i = 0; i < n; i++ )

		// Calculate space indexes
		for( j = 0; j < S_I_NN; j++ )
		{
			space_index[j] = 0;
		}

		j = 0;
		for( i = 0; i <= n; i++ )
		{
			if( ( ( usart_rx_data[i] == ' ' ) || ( usart_rx_data[i] == 0 ) ) && ( j < S_I_NN ) )
			{
				space_index[j++] = i;
				count_prm++;
			}
		}
		// -----------------------------------------------------------


		// -----------------------------------------------------------
		// Get param n_prm
		// -----------------------------------------------------------
		if( space_index[n_prm-1] )
		{
			if( n_prm == 1 )
			{
				n1 = 0;
				n2 = space_index[n_prm-1];
			}
			else
			{
				n1 = space_index[n_prm-2] + 1;
				n2 = space_index[n_prm-1];
			}

			for( i = n1; i < n2; i++ )
			{
				str[i-n1] = usart_rx_data[i];
			}
			str[i-n1] = 0;

//print_str( "\r\n>" );
//print_str( usart_rx_data );
//print_str( str );
//print_str( "<\r\n" );
//sprintf( s, "\r\nn_prm=%d n1=%d n2=%d %s<\r\n", n_prm, n1, n2, str ); print_str( s );

//for( j = 0; j < S_I_NN; j++ )
//{
//sprintf(s, "%d %d\r\n", j, space_index[j] ); print_str( s );
//}

		}
		//else
		//{
			//strcpy( str, ( char* ) usart_rx_data );
		//}
		// -----------------------------------------------------------





	}







	return count_prm;
}
//
//
//
//// ===========================================================================
//void parce_cmd( char *str, int *space_index, int m )
////void parce_cmd( char *str, int m )
//// ===========================================================================
//{
//	int	i, j, n;
//	//int		i, j, k, n, n1, m;
//	//int		space_index[6];		// max 6 params
//
//	n = strlen( ( char* ) usart_rx_data );
//	if( n )		// Length > 0
//	{
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//		// -----------------------------------------------------------
//		// Trim left spaces
//		// -----------------------------------------------------------
//		j = 0;
//		while( usart_rx_data[0] == ' ' )
//		{
//			n = strlen( ( char* ) usart_rx_data );
//			for( j = 0; j < n; j++ )
//			{
//				usart_rx_data[j] = usart_rx_data[j + 1];
//			}
//		}
//		// -----------------------------------------------------------
//
//
//		// -----------------------------------------------------------
//		// Trim right spaces
//		// -----------------------------------------------------------
//		n = strlen( ( char* ) usart_rx_data ) - 1;
//		if( n > 0 )
//		{
//			while( usart_rx_data[n] == ' ' )
//			{
//				if( n >= 0 )
//				{
//					usart_rx_data[n] = 0;
//					if( n )
//					{
//						n--;
//					}
//				}
//			}
//		}
//		// -----------------------------------------------------------
//
//
//		// -----------------------------------------------------------
//		// Prepare cmd string
//		// -----------------------------------------------------------
//		n = strlen( ( char* ) usart_rx_data );
//		for( i = 0; i < n; i++ )
//		{
//			if( ( usart_rx_data[i] < 32 ) || ( usart_rx_data[i] > 126 ) )
//			{
//				if( usart_rx_data[i] )
//				{
//					usart_rx_data[i] = '$';
//				}
//			}
//			if( usart_rx_data[i] > 96 )
//			{
//				usart_rx_data[i] -= 32;
//			}
//
//			while( ( usart_rx_data[i] == ' ' ) && ( usart_rx_data[i + 1] == ' ' ) )
//			{
//				for( j = i; j < n; j++ )
//				{
//					usart_rx_data[j] = usart_rx_data[j + 1];
//				}
//			}
//		}	// for( i = 0; i < n; i++ )
//
//		for( j = 0; j < m; j++ )
//		{
//			space_index[j] = 0;
//		}
//
//		j = 0;
//		for( i = 0; i < n; i++ )
//		{
//			if( ( usart_rx_data[i] == ' ' ) && ( j < m ) )
//			{
//				space_index[j++] = i;
//			}
//		}
//		// -----------------------------------------------------------
//
//
//		// -----------------------------------------------------------
//		// Get first param
//		// -----------------------------------------------------------
//		if( space_index[0] )
//		{
//			for( j = 0; j < space_index[0]; j++ )
//			{
//				str[j] = usart_rx_data[j];
//			}
//			str[j] = 0;
//		}
//		else
//		{
//			strcpy( str, ( char* ) usart_rx_data );
//		}
//		// -----------------------------------------------------------
//	}
//	else
//	{
//		str[0] = 0;
//	}
//	return;
//}
//// ===========================================================================
//
//
//// ===========================================================================
//void parce_prm( char *str, int nn, int *space_index, int space_index_size )
//// ===========================================================================
//{
//	int	i, j, n;
//
//	str[0] = 0;
//	if( ( nn > 0 )  && ( nn <= space_index_size ) )
//	{
//		if( space_index[nn-1] )
//		{
//			if( space_index[nn] )
//			{
//				i = 0;
//				for( j = ( space_index[nn-1] + 1 ); j < space_index[nn] + 1; j++ )
//				{
//					str[i++] = usart_rx_data[j];
//				}
//				str[i] = 0;
//			}	// if( space_index[2] )
//			else
//			{
//				n = strlen( ( char* ) usart_rx_data );
//				i = 0;
//				for( j = ( space_index[nn-1] + 1 ); j < n; j++ )
//				{
//					str[i++] = usart_rx_data[j];
//				}
//				str[i] = 0;
//			}	// else -- if( space_index[4] )
//		}
//		else
//		{
//			str[0] = 0;
//		}
//	}
//	else
//	{
//		str[0] = 0;
//	}
//}
//// ===========================================================================

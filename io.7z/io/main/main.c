#include "mx_init_hw.c"

/*
ch port GPIO Type
-- ---- ---------
 1 PA1  (1) DS18B20
 2 PB11 (4) bidirectional GPIO pullup
 3 PB10 (4) bidirectional GPIO pullup
*/

// ===========================================================================
int main()
// ===========================================================================
{
	char	s[128];		// For print
	float	f;

	Init_HW();

	// ---------------------------------------------------------------------------
	// The main program loop
	// ---------------------------------------------------------------------------
	while( TRUE )
	{
//print_str( "---\r\n" );
		delay_ms( 300 );
		LCD_write_string( 1, "1 - 123" );
		LCD_write_string( 2, "2 - 123" );
//
//
//if( read_ch( 3 ) )
//{
//    write_ch( 2, 0 );
//		LCD_write_string( 1, "Button Off" );
//}
//else
//{
//    write_ch( 2, 1 );
//		LCD_write_string( 1, "Button On" );
//}
//
//		f = read_ch( 1 ) / 10.0;
//		sprintf( s, "t=%03.1f \337C", f );
//		LCD_write_string( 2, s );
	}	// while( TRUE )
}
// ===========================================================================



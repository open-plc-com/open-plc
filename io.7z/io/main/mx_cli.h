#ifndef __mx_cli_H
#define __mx_cli_H

#ifdef __cplusplus
	extern "C" {
#endif

void cli( void );

#ifdef __cplusplus
}
#endif

#endif /* __mx_cli_H */

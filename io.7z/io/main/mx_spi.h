#ifndef __mx_spi_H
#define __mx_spi_H

#ifdef __cplusplus
	extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /* __mx_spi_H */

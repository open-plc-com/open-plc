#ifndef __PD__
#define __PD__
#define PD_NN 4
struct PD_Struct
{
	char		name[10];
	uint64_t	data;
	char		data_type;	// C-char; I-int64_t; U-uint64_t (raw); F-float (double)
	char		comment[34];
}	volatile	PD[PD_NN];
void init_pd()
{
strcpy( (char*) PD[0].name, "00000001" ); PD[0].data = 0x3737373737; PD[0].data_type = 'C'; strcpy( (char*) PD[0].comment, "Comment #1" );
strcpy( (char*) PD[1].name, "00000002" ); PD[1].data = (uint64_t)-123; PD[1].data_type = 'I'; strcpy( (char*) PD[1].comment, "Comment #2" );
strcpy( (char*) PD[2].name, "00000003" ); PD[2].data = 1234567; PD[2].data_type = 'U'; strcpy( (char*) PD[2].comment, "Comment #3" );
strcpy( (char*) PD[3].name, "00000004" ); PD[3].data = 0; PD[3].data_type = 'F'; strcpy( (char*) PD[3].comment, "Comment #4" );
}

int search_pd_by_name( char *name )
{
	int i, n;
	n = -1;
	for( i = 0; i < PD_NN; i++ )
	{
		if( !strcmp( name, (char*) PD[i].name ) )
		{
			n = i;
			break;
		}
	}
	return n;
}

int write_pd( char *name, uint64_t val )
{
	int n;
	uint64_t *p;
	n = search_pd_by_name( name );
	if( n > -1 )
	{
		PD[n].data = val;
		return 0;
	}
	else
	{
		return 1; // variable name not found
	}
}

int read_pd( char *name, uint64_t *val )
{
	int n;
	uint64_t *p;
	n = search_pd_by_name( name );
	if( n > -1 )
	{
		*val = PD[n].data;
		return PD[n].data_type;
	}
	else
	{
		return 1; // variable name not found
	}
}




//int write_pd_char( char *name, char *val )
//{
//	int n;
//	uint64_t *p;
//	n = search_pd_by_name( name );
//	if( n > -1 )
//	{
//		if( PD[n].data_type != 'C' )
//		{
//			return 2; // variable type is not char
//		}
//		if( strlen( val ) > 8 )
//		{
//			return 3; // lenght of val more then 8 char
//		}
//		p = (uint64_t*) &val[0];
//		PD[n].data = *p;
//		return 0;
//	}
//	else
//	{
//		return 1; // variable name not found
//	}
//}
//
//int write_pd_uint( char *name, uint64_t val )
//{
//	int n;
//	//char		*s;
//	//n = -1;
//	//for( i = 0; i < PD_NN; i++ )
//	//{
//		//if( !strcmp( name, (char*) PD[i].name ) )
//		//{
//			//n = i;
//			//break;
//		//}
//	//}
//	n = search_pd_by_name( name );
//	if( n > -1 )
//	{
//		if( PD[n].data_type != 'U' )
//		{
//			return 2; // variable type is not unsigned integer
//		}
//		PD[n].data = val;
//		return 0;
//	}
//	else
//	{
//		return 1; // variable name not found
//	}
//}
//
//int write_pd_int( char *name, int64_t val )
//{
//	int			n;
//	//char		*s;
//	//n = -1;
//	//for( i = 0; i < PD_NN; i++ )
//	//{
//		//if( !strcmp( name, (char*) PD[i].name ) )
//		//{
//			//n = i;
//			//break;
//		//}
//	//}
//	n = search_pd_by_name( name );
//	if( n > -1 )
//	{
//		if( PD[n].data_type != 'I' )
//		{
//			return 2; // variable type is not integer
//		}
//		PD[n].data = (uint64_t) val;
//		return 0;
//	}
//	else
//	{
//		return 1; // variable name not found
//	}
//}
//
//int write_pd_float( char *name, double val )
//{
//	int			n;
//	uint64_t	*f;
//	//char		*s;
//	n = search_pd_by_name( name );
//	if( n > -1 )
//	{
//		if( PD[n].data_type != 'F' )
//		{
//			return 2; // variable type is not float
//		}
//		f = (uint64_t*) &val;
//		PD[n].data = *f;
//		return 0;
//	}
//	else
//	{
//		return 1; // variable name not found
//	}
//}
//
//int read_pd_char( char *name )
//{
//	int			i, m, n;
//	//uint64_t	*f;
//	char		*s;
//	//uint64_t	*p;
//	n = search_pd_by_name( name );
//	if( n > -1 )
//	{
//		if( PD[n].data_type != 'C' )
//		{
//			name[0] = 0;
//			return 2; // variable type is not char
//		}
//		for( i = 0; i < 10; i++ )
//		{
//			name[i] = 0;
//		}
//		s = (char*) &PD[n].data;
//		m = strlen( s );
//		if( m > 8 )
//		{
//			m = 8;
//		}
//		for( i = 0; i < m; i++ )
//		{
//			name[i] = s[i];
//		}
//		return 0;
//	}
//	else
//	{
//		return 1; // variable name not found
//	}
//}
//
//int read_pd_int( char *name, int64_t *val )
//{
//	int n;
//	//int			i, n;
//	//uint64_t	*f;
//	//char		*s;
//	//uint64_t	*p;
//	n = search_pd_by_name( name );
//	if( n > -1 )
//	{
//		if( PD[n].data_type != 'I' )
//		{
//			return 2; // variable type is not int
//		}
//		*val = PD[n].data;
//		return 0;
//	}
//	else
//	{
//		return 1; // variable name not found
//	}
//}
//
//int read_pd_uint( char *name, uint64_t *val )
//{
//	int n;
//	//int			i, n;
//	//uint64_t	*f;
//	//char		*s;
//	//uint64_t	*p;
//	n = search_pd_by_name( name );
//	if( n > -1 )
//	{
//		if( PD[n].data_type != 'I' )
//		{
//			return 2; // variable type is not uint
//		}
//		*val = PD[n].data;
//		return 0;
//	}
//	else
//	{
//		return 1; // variable name not found
//	}
//}
//
////int write_pd_data( char *name, uint64_t val )
////{
//
////}




#endif // __PD__
